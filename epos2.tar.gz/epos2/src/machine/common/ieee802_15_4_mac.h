// EPOS IEEE 802.15.4 MAC Implementation

#include <system/config.h>
#ifndef __no_networking__

#include <nic.h>

__BEGIN_SYS

// Class attributes

// Methods

__END_SYS

#endif
