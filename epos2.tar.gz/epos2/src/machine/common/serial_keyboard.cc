// EPOS Serial Keyboard Mediator Implementation

#include <keyboard.h>

__BEGIN_SYS

// Class attributes
Observed Serial_Keyboard::_observed;

__END_SYS
