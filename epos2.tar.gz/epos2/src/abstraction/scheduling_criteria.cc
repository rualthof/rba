// EPOS CPU Affinity Scheduler Abstraction Implementation

#include <scheduler.h>

__BEGIN_SYS

// Class attributes
volatile unsigned int Scheduling_Criteria::Variable_Queue::_next_queue;

__END_SYS
