 
#include <utility/ostream.h>

using namespace EPOS;

OStream cout;

int main(){
    
    while(1){
      for(int i = 0; i < 100000000; i++);
    
        cout << "Hello World" << endl;  
    }
    
    return 0;
}
