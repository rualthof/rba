#include <pwm.h>
#include <gpio.h>

using namespace EPOS;

int main(){
    
    GPIO *g = new GPIO('D', 5, GPIO::OUT);
    
    //User_Timer_Engine *timer;
}
