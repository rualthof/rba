// EPOS Communication Channel Abstraction Declarations

#ifndef __channel_h
#define __channel_h

#include <udp.h>
#include <tcp.h>

#endif
