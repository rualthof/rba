// EPOS PWM Mediator Common package

#ifndef __i2c_h
#define __i2c_h

#include <system/config.h>

__BEGIN_SYS

class PWM_Common
{
protected:
    PWM_Common() {}
};

__END_SYS

#ifdef __PWM_H
#include __PWM_H
#endif

#endif
