// EPOS Run-Time System Information

#ifndef __info_h
#define __info_h

#include <system/config.h>

#include __HEADER_MACH(info)

#endif
